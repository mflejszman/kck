# kck
zajęcia z przedmiotu komunikacja człowiek komputer
Podstawowe znaczniki umożliwiające formatowanie:

# nagłowek poziomu 1 #
## nagłówek poziomu 2 ##

#### nagłówek poziomu 4 ####
#### nagłówek poziomu 4

**pogrubienie** lub __pogrubienie_'
**Pogrubienie**   __pogrubienie__


``` Kod programu
for(i=1; i<=10; i++)
{
if(i % 2 == 0) document.write(i + "<br>")
}
```



- ggggg
- Punkt 1
- Punkt 2
- Podpunkt 2.1
- Punkt 3
 - Punkt11



>Cytowanie
